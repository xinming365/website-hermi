<template>
<div style="font-size: 16px; line-height: 1.75;">
<div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
<div style="width: 675px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/解决方案-半导体大图-FvdHZuxrb9pW2LjidlaB8pD8ImDh.jpg" width="675"></div>
<div style="width: 675px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">半导体</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">半导体行业是电子信息产业的重要组成部分，以半导体材料为基础，涵盖设计、制造、封装三大环节。该行业在推动科技进步和经济发展中发挥着关键作用，广泛应用于智能手机、电脑、家用电器、电动汽车等多个领域，是现代电子设备的核心。随着科技的进步和市场的不断扩大，半导体行业正迎来新的发展机遇和挑战。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">半导体加工中的碳化硅切割、晶圆退火、PCB钻孔、TGV钻孔等多道加工工序，激光加工有着非常大的优势。LBTEK提供的多焦点整形、方形（圆形）匀化光斑、椭圆贝塞尔光斑等光束整形技术可极大提升这些工序的加工质量与加工效率。此外，LBTEK还可以提供激光加工系统中配套的高功率扩束镜、场镜、反射镜、波片等光学元件，以及相关的高稳定性镜架等。</p>
</div>
</div>
</div>
</template>