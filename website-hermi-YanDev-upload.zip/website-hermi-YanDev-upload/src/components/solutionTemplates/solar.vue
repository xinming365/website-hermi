<template>
<div style="font-size: 16px; line-height: 1.75;">
<div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
<div style="width: 675px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/解决方案-光伏大图-FgmpeDPtos_wLfEVG-pDR-h6ZiV7.jpg" width="675"></div>
<div style="width: 675px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">光伏</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">光伏大行业是利用太阳能资源，通过光伏效应将光能转化为电能的绿色能源产业，近年来在全球能源转型和碳中和目标的推动下，展现出强劲的增长势头和广阔的发展前景。光伏的应用场景非常广泛，光伏电站、家庭屋顶、商业建筑、工业厂房、电动汽车充电站、太阳能路灯等，降低了用电成本，还减少了对传统能源的依赖，符合节能环保的趋势。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">为了助力光伏行业发展，LBTEK针对太阳能电池制备中的激光掺杂、烧结、划线、减薄等多品类电池、多道工序提供光束整形加工系统，不仅包含激光整形元件（液晶、刻蚀）、扩束镜、场镜、反射镜、波片等光学元件，还能提供配套的各类高稳定性元件/组件安装镜架，为太阳能电池制造降本增效增质提供助力。</p>
</div>
</div>
</div>
</template>