<div style="font-size: 16px; line-height: 1.75;">
    <div style="width: 100%; height: 340px; background: url('https://images.lbtek.com/mall/tinymce/生物光子-FqDOhxje5cZ_n64XEWUdSQAiFIAf.jpg'); border-radius: 6px; overflow: hidden; padding: 50px 0 0 50px; box-sizing: border-box;">
    <div style="width: 700px; height: 100%; color: #fff; background: rgba(0,0,0,.5);">
    <h3 style="font-size: 28px; margin-bottom: 10px;">生物光子学</h3>
    <p>生物光子学是关于光与生物组织相互作用所产生的效应及其应用的学科。它是交叉于光学、光电子学、生物学、医学、电子学等诸多领域的新学科，其应用涉及到从生物学研究、医学疾病诊断、治疗到预防的宽广的应用范围。</p>
    </div>
    </div>
    <div style="width: 100%; height: 50px; background: #f3f3f3; color: #c6231d; font-size: 28px; font-weight: bold; line-height: 50px; text-align: center; margin: 30px 0;">研究方向</div>
    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
    <div style="width: 700px;"><img src="https://images.lbtek.com/mall/tinymce/结构光照明超分辨显微镜（SIM）光路图-FgEbcgYIgKMd1sXvLnDQSn5iut0v.jpg" width="700"></div>
    <div style="width: 700px;">
    <h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">01 超分辨成像</h3>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">由于光的衍射特性，一个物点发出的光会形成一个弥散斑（也称艾里斑），当二个物点靠近的时候，达到一定程度就不能再区分开来，通常我们把200 nm称为分辨率极限。超分辨成像即为突破衍射极限，实现纳米级的分辨率。</p>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的超分辨成像核心器件：激光器、物镜、位移台、空间光调制器、sCMOS，以及整套SIM超分辨荧光成像系统。</p>
    </div>
    </div>
    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
    <div style="width: 700px;">
    <h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">02 组织光学与光谱成像</h3>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">组织光学与光谱成像针对不同尺度、不同生理特性组织，研究光与不同生理特性的生物组织的相互作用规律，探索生物医学的成像机制。在此基础上，针对重大疾病的光诊断与光治疗的原理与方法展开研究，为疾病的早期诊断、治疗、及疗效评价提供新的途径，并最终服务于临床。</p>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的组织光学与光谱成像核心器件： 激光器、超高速数字微镜空间光调制器、高速相机、探测器等，以及整套OCT系统。</p>
    </div>
    <div style="width: 700px;"><img src="https://images.lbtek.com/mall/tinymce/动态荧光层析成像-FoWRPg4_RWoi_GthkCxLMtD3GnfU.jpg"></div>
    </div>
    <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
    <div style="width: 700px;"><img src="https://images.lbtek.com/mall/tinymce/全息光镊系统-FmFAjzy-xZluqkeNSUEGZUDw9KYR.jpg"></div>
    <div style="width: 700px;">
    <h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">03 生物光学传感与调控</h3>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">生物光学传感与调控在分子水平上对生物组织结构与功能进行监测与调控，涉及对生物系统以光子形式释放的能量与来自生物系统的光子的探测、对这些光子携带的有关生物系统的结构与功能信息的监测、及利用光子对系统的加工与改造。在医学研究领域，以非侵入的方式，实现宏观与微观尺度分子水平的疾病探测、诊断和治疗。</p>
    <p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的生物光学传感与调控核心器件： 激光器、物镜、位移台、空间光调制器、探测器等，以及整套的单光束光镊系统、涡旋光镊系统。</p>
    </div>
    </div>
    </div>