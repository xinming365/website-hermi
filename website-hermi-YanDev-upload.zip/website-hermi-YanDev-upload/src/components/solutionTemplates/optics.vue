<template>
<div style="font-size: 16px; line-height: 1.75;">
<div style="width: 100%; height: 340px; background: url('https://images.lbtek.com/mall/tinymce/光谱-FuLQTlDQg4AFG24A09HdsiuiDcK2.jpg'); border-radius: 6px; overflow: hidden; padding: 50px 0 0 50px; box-sizing: border-box;">
<div style="width: 700px; height: 100%; color: #fff; background: rgba(0,0,0,.5);">
<h3 style="font-size: 28px; margin-bottom: 10px;">光谱学</h3>
<p>光谱技术是近代光学计量的重要分支，通过对物质光谱的探测、分析来获取物质的组成、结构、含量等信息。不仅可以识别和分析未知物质，还为新材料的发现、疾病诊断、环境监测等提供了强有力的支持。光谱技术广泛用于工业、农业、地质、艺术、医学、海洋、火星探测、核聚变和核安全等领域。</p>
</div>
</div>
<div style="width: 100%; height: 50px; background: #f3f3f3; color: #c6231d; font-size: 28px; font-weight: bold; line-height: 50px; text-align: center; margin: 30px 0;">研究方向</div>
<div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
<div style="width: 700px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/图1-FoH6G_JCSuQzp3yACJsV1QF7AFQk.jpg" width="700"></div>
<div style="width: 700px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">01 拉曼光谱</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">拉曼与入射光的频率无关，只与物质分子的振动和转动能级有关，不同物质分子具有不同的振动和转动能级，有特定的拉曼位移，因此拉曼可以用来鉴定物质结构的分析和研究，也叫做物质的指纹。其基本原理是通过激光照射样品，收集不同谱段的拉曼散射，形成拉曼光谱。拉曼光谱的峰位、峰强和峰宽可以分别提供物质的结构、化学成分、含量以及结晶程度等信息。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的拉曼光谱技术核心组件：激光器（输出高强度的单色光）、显微模块（增强信号）、色散元件（按波长分离光）、扩束模块（功率密度更高激发更强的拉曼信号）、探测器（以高灵敏度和分辨率捕捉和记录光谱信号）、sCMOS（兼顾相元大尺寸、制冷型、宽光谱噪声低实现高精度测量）。</p>
</div>
</div>
<div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
<div style="width: 700px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">02 超快光谱</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">超快光谱探测技术，是指利用脉冲激光器对样品进行激光刺激，并用激光对刺激后的样品进行探测，以研究样品在极短时间内的光物理、光化学和光生物反应的一种方法，超快光谱探测技术类似超快摄像机一样，让人们能够通过一帧一帧的慢动作观察处于化学反应过程中原子与分子的转变状态。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的超快光谱技术核心组件： 激光器（输出皮秒脉冲）、手动/电动延迟线（用空间换时间）、超快反射镜（减弱镜片对光束脉宽的影响）。</p>
</div>
<div style="width: 700px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/图2-Fhv_8uaXm-NGiKswkUxhV91QC4j-.jpg"></div>
</div>
<div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
<div style="width: 700px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/图3-Fv5bf3ep_1SIagH3AEFPFXesRozH.jpg"></div>
<div style="width: 700px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">03 激光诱导击穿光谱</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">脉冲激光器产生的高能激光脉冲能够诱导样品表面发生击穿现象，产生等离子体，进而通过光谱仪收集等离子体发出的光谱信号，实现对样品成分的分析。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的LIBS核心组件： 激光器（输出皮秒脉冲）、聚焦系统（以更高的能量对样品进行击穿）、探测器（以高灵敏度和分辨率捕捉和记录光谱信号）、sCMOS（兼顾相元大尺寸、制冷型、宽光谱噪声低实现高精度测量）、光谱仪。</p>
</div>
</div>
</div>
</template>