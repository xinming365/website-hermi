<template>
<div style="font-size: 16px; line-height: 1.75;">
<div style="display: flex; justify-content: space-between; margin-bottom: 20px;">
<div style="width: 675px; height: 320px;"><img src="https://images.lbtek.com/mall/tinymce/解决方案-锂电大图-FmAvvaRH6hR53RqMkEYzSeV9a-4i.jpg" width="675"></div>
<div style="width: 675px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">锂电</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">锂电池行业是一个快速发展的领域，该行业以高能量密度、长循环寿命和环保性能为特点，广泛应用于新能源汽车、便携式电子设备、储能系统等多个领域，是推动全球能源转型和绿色发展的重要力量。随着技术进步和市场需求的不断增长，锂电池行业正迎来更加广阔的发展前景。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">针对锂电加工行业对光束整形的需求，LBTEK提供的分束、匀化、复合点环、多焦点长焦深等多种整形方案，广泛应用在锂电池制造中的快充扩容、极片清洗、极耳切割、顶盖焊接等多道工序中。除此之外，麓邦设计开发配套的扩束镜、场镜、反射镜、波片等光学元件，能够最大化整形光束为激光加工带来的优势。</p>
</div>
</div>
</div>	
</template>