<template>

<div style="font-size: 16px; line-height: 1.75;">
<div style="width: 100%; height: 340px; background: url('https://images.lbtek.com/mall/tinymce/精密测量-Fr5AYci43EIbeYwistd0p0hI-CA1.jpg'); border-radius: 6px; overflow: hidden; padding: 50px 0 0 50px; box-sizing: border-box;">
<div style="width: 700px; height: 100%; color: #fff; background: rgba(0,0,0,.5);">
<h3 style="font-size: 28px; margin-bottom: 10px;">精密测量</h3>
<p>精密测量是科学研究的基石，它不仅推动了物理学、化学、生物学等基础学科的发展，也在工程、材料科学、纳米技术等应用领域发挥着至关重要的作用。随着技术的进步，我们对测量精度的要求已经从宏观世界扩展到微观甚至原子尺度，测量范围从毫米级到纳米级，乃至于更小。</p>
</div>
</div>
<div style="width: 100%; height: 50px; background: #f3f3f3; color: #c6231d; font-size: 28px; font-weight: bold; line-height: 50px; text-align: center; margin: 30px 0;">研究方向</div>
<div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
<div style="width: 700px;"><img src="https://images.lbtek.com/mall/tinymce/外差干涉仪的非线性模型-非双频混频-FhNasAltUbzAXhnT6oxnGMGqO3jk.jpg" width="700"></div>
<div style="width: 700px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">01 干涉测量</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">干涉测量是一种基于波的干涉现象进行精密测量的技术，利用了波（如光波、无线电波或声波）的干涉特性，通过测量波在不同路径中的相位差异来获取信息。由于光波的波长非常短，即便是非常小的光路差异也能被检测出来，并在干涉图上产生明显的变化。干涉测量广泛用于光谱学、天文学、生物医学、材料科学等领域。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的干涉测量核心器件：激光器、分束器、反射镜、探测器等，并可承接定制系统方案。</p>
</div>
</div>
<div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
<div style="width: 700px;">
<h3 style="font-size: 20px; height: 40px; line-height: 40px; background: linear-gradient(90deg,#b91c23,#e7bc7c); color: #fff; padding-left: 20px; box-sizing: border-box; margin-bottom: 10px;">02 量子测量</h3>
<p style="color: #666; font-size: 18px; text-indent: 2em;">量子测量是一种利用量子力学原理来实现超越传统测量技术极限的精密测量技术。它通过操控量子系统，如原子、光子或固态量子比特，达到对物理量的极端敏感探测。量子测量的应用范围广泛，包括但不限于精密时钟、量子导航、单量子灵敏探测、量子成像和量子雷达系统等。</p>
<p style="color: #666; font-size: 18px; text-indent: 2em;">LBTEK提供优质齐全的组织光学与光谱成像核心器件：光源、波片、单光子探测器等，并可承接定制系统方案。</p>
</div>
<div style="width: 700px;"><img src="https://images.lbtek.com/mall/tinymce/海森堡极限的量子精密测量-FsB60SS5CvPt1SJmkPy-S-Ntat3r.jpg"></div>
</div>
</div>
</template>