<template>
    <div class="lb-product-center">
        <div class="auto-content">
				<div class="lb-product-center__main">
						<div class="lb-product-center-section lb-product-center-section--1">
				<div class="lb-product-center-section__title"><span>微纳光学</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=371" title="涡旋波片及相位板">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/涡旋波片阵列-FsRBD0d9OApC4XICbwP_ALQNamRO.jpg"/>
															</div>
							<div class="lb-product-center-section__text">涡旋波片及相位板</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=248" title="衍射透镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/衍射透镜二级分类图-FnUuNUxuHH90R9JtcGU1xbVvK54Q.jpg"/>
															</div>
							<div class="lb-product-center-section__text">衍射透镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=247" title="衍射光栅">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/衍射光栅二级分类-FuWV187pmyd4-WYjSbuRluMGrS7s.jpg"/>
															</div>
							<div class="lb-product-center-section__text">衍射光栅</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=245" title="光场调控">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光场调控二级分类-FtX0VRC5ScXLDdRcxIbmSlCP7qRR.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光场调控</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=249" title="匀化DOE">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/匀化DOE二级分类-Fn91T-3BF9knKkeNfkeokw0nPKXG.jpg"/>
															</div>
							<div class="lb-product-center-section__text">匀化DOE</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=261" title="分束DOE">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/分束DOE二级分类-FjtZRYXEPdasYmeKDN0PyuVPZnRP.jpg"/>
															</div>
							<div class="lb-product-center-section__text">分束DOE</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=290" title="焦点整形DOE">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/焦点整形DOE-Fh9ZSL4VNyke3yQ2CP46Um-PyXkt.jpg"/>
															</div>
							<div class="lb-product-center-section__text">焦点整形DOE</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/148?sid=250" title="衍射光学元件定制">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/衍射光学元件定制-Fhgt0_7h2_sdvgnX6rqUZIZQIYak.jpg"/>
															</div>
							<div class="lb-product-center-section__text">衍射光学元件定制</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--2">
				<div class="lb-product-center-section__title"><span>光学元件</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=29" title="偏振光学">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/偏振光学元件分类图-FkbNSR8DC9_O_xo1jziyF_zUrfPz.jpg"/>
															</div>
							<div class="lb-product-center-section__text">偏振光学</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=30" title="反射镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/反射镜分类图-FlGiBM4shN_GnsOcydWRTnXR746J.jpg"/>
															</div>
							<div class="lb-product-center-section__text">反射镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=35" title="透镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/透镜分类图-FsGkIuUAgRyt21MtkzcHzEA95Tit.jpg"/>
															</div>
							<div class="lb-product-center-section__text">透镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=31" title="分束镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/分束镜组合-FvMMKKHrOLxeCMjXI61xYUigKl1B.jpg"/>
															</div>
							<div class="lb-product-center-section__text">分束镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=32" title="滤光片">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/滤光片分类图-Fqz-gL_eq7fKLv-ziw6pWO0sTt9u.jpg"/>
															</div>
							<div class="lb-product-center-section__text">滤光片</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=33" title="棱镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/棱镜分类图-FiLfyBb9RwUP3aJHykJ_nfmOBsfj.jpg"/>
															</div>
							<div class="lb-product-center-section__text">棱镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=34" title="窗口片">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/窗口片组合图-FjRtiWCrXQX5CEKa-vowDHyKZFl1.jpg"/>
															</div>
							<div class="lb-product-center-section__text">窗口片</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/28?sid=176" title="散射片">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/散射片分类图-Fi1w_KvWq_mu49fLt9DjF35z04Bx.jpg"/>
															</div>
							<div class="lb-product-center-section__text">散射片</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--3">
				<div class="lb-product-center-section__title"><span>光学系统</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=131" title="激光扩束器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/激光扩束器分类图-FjsdBQBFvz-Vwr0SHrw0cCKMOtNm.jpg"/>
																<i class="new-icon"></i>
															</div>
							<div class="lb-product-center-section__text">激光扩束器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=188" title="旋光器及隔离器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/旋光器及隔离器二级分类图-FqyJLezDlEeFW0dWLeN-yt78bVzm.jpg"/>
															</div>
							<div class="lb-product-center-section__text">旋光器及隔离器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=214" title="物镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/物镜二级分类图-FjGmK_NBMXbWTOrOZdgSl8zLyz55.jpg"/>
															</div>
							<div class="lb-product-center-section__text">物镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=236" title="成像镜头">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/成像镜头二级分类图-FoRlRpFSxzNXX0xlUflZQQOFYNhF.jpg"/>
															</div>
							<div class="lb-product-center-section__text">成像镜头</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=253" title="剪切干涉仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/剪切干涉仪-FhjurFy2xuGF-2aiYP9HbE0NCHgp.jpg"/>
															</div>
							<div class="lb-product-center-section__text">剪切干涉仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=393" title="贝塞尔加工头">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/贝塞尔加工头分类图-FsJ5Z2PYAVi2wXr-0gF5srG5yOAw.jpg"/>
															</div>
							<div class="lb-product-center-section__text">贝塞尔加工头</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=276" title="场镜">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/场镜-FmMujtEsyPyslADd47qQUmSDaFU2.jpg"/>
															</div>
							<div class="lb-product-center-section__text">场镜</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/146?sid=388" title="光机模块">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光机模块分类图-FoAUts8pUp9j_ubYSr3XbDXyHZbB.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光机模块</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--4">
				<div class="lb-product-center-section__title"><span>光纤及光纤组件</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=172" title="光纤准直/耦合器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤准直器-FgCe7PftQU7VYifXFrlET4wNYzBR.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤准直/耦合器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=130" title="光纤及光纤跳线">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤及光纤跳线二级分类图-Fi6z4pAzNmjykRE2-SrZALCCh9rH.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤及光纤跳线</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=170" title="光纤法兰">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤法兰-FtRxYmnjG-G8Zh8YRaT0pPJ3mrhF.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤法兰</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=226" title="光纤隔离器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤隔离器-FtBcioxGDwsUz77N2_uVeTjAU45Z.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤隔离器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=228" title="光纤衰减器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤衰减器-FsRF7ZyWquv9TtJHgOCrSqpYl_lQ.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤衰减器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=255" title="光纤偏振控制器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤偏振控制器-FgS4vvLYGqTX_ocOlKgisCGDqkZI.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤偏振控制器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=395" title="光纤组件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤组件分类图-FreSHGbw3TRptsXvVLWFqwsLAabN.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤组件</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/129?sid=396" title="光纤工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光纤工具分类图-FpctqoHlpiqp3dBaJMnbWrqSUWnN.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光纤工具</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--5">
				<div class="lb-product-center-section__title"><span>光学平台与面包板</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=365" title="阻尼隔振光学平台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/阻尼隔振光学平台-FnlSYdAwkWHf6ebjDNKNQ2QaYl2z.jpg"/>
															</div>
							<div class="lb-product-center-section__text">阻尼隔振光学平台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=367" title="气浮隔振光学平台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/气浮隔振光学平台-FlzuL1plwhTeaq21Uyw3xqFvO_pu.jpg"/>
															</div>
							<div class="lb-product-center-section__text">气浮隔振光学平台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=366" title="气浮摆杆光学平台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/气浮摆杆隔振光学平台-FimVlENzkJhP22FZtiPZ11EXwBeC.jpg"/>
															</div>
							<div class="lb-product-center-section__text">气浮摆杆光学平台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=368" title="蜂窝光学面包板">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/蜂窝光学面包板-FikzpN8VVBu-OoGchGAwsaKckO2g.jpg"/>
															</div>
							<div class="lb-product-center-section__text">蜂窝光学面包板</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=377" title="标准面包板及配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/面包板与配件分类图-FnVSBKwHZ2LssCI8VPOUlAQoPc4k.jpg"/>
															</div>
							<div class="lb-product-center-section__text">标准面包板及配件</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=378" title="光学平台仪器架">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/6光学平台仪器架分类图（新增）-FkCAOjnF5gcmkC9H9DPOPjSDgAQF.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光学平台仪器架</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=369" title="遮光帘">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光学平台组合式仪器架遮光帘-FjPUR_XkSXdSWucF1PcO924gu8-n.jpg"/>
															</div>
							<div class="lb-product-center-section__text">遮光帘</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/185?sid=370" title="光学罩箱">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光学罩壳-Fmx_YJDA3zntyGNE4byYl1dtbrxb.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光学罩箱</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--6">
				<div class="lb-product-center-section__title"><span>光机械件</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=103" title="光学元件安装架">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光学元件安装架分类图-FuCIhyWta_GQu0LaLXOqtpKprovj.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光学元件安装架</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=73" title="同轴系统">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/同轴系统分类图-FrP-EfMMmgCf23-BeSkWB_0dD2HR.jpg"/>
															</div>
							<div class="lb-product-center-section__text">同轴系统</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=78" title="基础安装件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/基础安装件分类图-FpLmSymngnv3Af7H1cxhd15L4M0T.jpg"/>
															</div>
							<div class="lb-product-center-section__text">基础安装件</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=75" title="透镜套筒及配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/透镜套筒-FntqH_zmLD9y_luW7pU5re1OCwe1.jpg"/>
															</div>
							<div class="lb-product-center-section__text">透镜套筒及配件</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=202" title="MT高稳镜架">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/MT-高稳系列产品-FvTAnSGZuFKK4vFXzeUpSdBw5SeS.jpg"/>
															</div>
							<div class="lb-product-center-section__text">MT高稳镜架</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=74" title="光阑/针孔/狭缝">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/二级分类图光阑针孔狭缝-FvlSbsY5TYDSLTiry5ylyCN6u2d8.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光阑/针孔/狭缝</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/36?sid=187" title="机械组件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/机械组件-FqyMwieDE3TftrXfQPqemDFJgU8V.jpg"/>
															</div>
							<div class="lb-product-center-section__text">机械组件</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--7">
				<div class="lb-product-center-section__title"><span>运动控制</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=233" title="手动直线位移台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/手动直线位移台分类图2-Fp7Pzy7TU4ukZnJVWZyLyTe1kz_Y.jpg"/>
															</div>
							<div class="lb-product-center-section__text">手动直线位移台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=390" title="多轴位移台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/多轴位移台分类图-FopE3wC02nwR0ukq3N-wurorbBXY.jpg"/>
															</div>
							<div class="lb-product-center-section__text">多轴位移台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=232" title="旋转/角位移台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/旋转位移台及角位移台-FrDRDX5dBJkLhV4V9Epfi_PwOTeQ.jpg"/>
															</div>
							<div class="lb-product-center-section__text">旋转/角位移台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=382" title="电动直线位移台">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/电动直线位移台3-FnGak5fn_SKr5x9FbOICMtj1syNh.jpg"/>
															</div>
							<div class="lb-product-center-section__text">电动直线位移台</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=385" title="电动光机装置">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/其他电动光机装置-FogR-fj4xSP5gKay676n6N1plYkg.jpg"/>
															</div>
							<div class="lb-product-center-section__text">电动光机装置</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/183?sid=234" title="运动控制配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/微分头促动器光纤夹具-FsOU3TjZtUvDMnsY7v5J7-qlZQ6l.jpg"/>
															</div>
							<div class="lb-product-center-section__text">运动控制配件</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--8">
				<div class="lb-product-center-section__title"><span>实验室工具</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=158" title="安装工具及配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/实验室工具一级分类图-Fm30cuGXxvvUH-qkSNufo3SPpXK2.jpg"/>
															</div>
							<div class="lb-product-center-section__text">安装工具及配件</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=161" title="光路调试工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光路调试工具分类图-Fjhna-tQpD8UKj4xc9PJNbE1nq83.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光路调试工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=394" title="检测工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/测试靶01-FjoitMgUGMe7GZkTnS48gKilb4Sf.jpg"/>
															</div>
							<div class="lb-product-center-section__text">检测工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=220" title="精密测量工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/精密测量工具分类图-FkstHgYGeLslv6m4agwi6YyNNJx4.jpg"/>
															</div>
							<div class="lb-product-center-section__text">精密测量工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=280" title="显微实验工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/组合-Fh9FxYmSJx10gjI2U9XG8ObkvJqh.jpg"/>
															</div>
							<div class="lb-product-center-section__text">显微实验工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=175" title="清洁及存放工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/组合图-FsANdO8Pzpz0J_ii77ZwT1C6Wkfm.jpg"/>
															</div>
							<div class="lb-product-center-section__text">清洁及存放工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=159" title="防护工具">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/组合大图-FgkZ1LzzUDaEks2A4iIakUj_HFj-.jpg"/>
															</div>
							<div class="lb-product-center-section__text">防护工具</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/147?sid=354" title="实验室仪器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/液体温度控制器-FpJUt0yYOvMAH3wYIppoQXlsKR_1.jpg"/>
															</div>
							<div class="lb-product-center-section__text">实验室仪器</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--9">
				<div class="lb-product-center-section__title"><span>光电探测与分析</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=267" title="光功率计及能量计">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/激光能量及功率计-Fk9rUSvFDGGWnM804707jYUcR2Ff.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光功率计及能量计</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=391" title="单光子探测">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/单光子探测器分类图-FgJYzaP1Dfp6RpbtpuGNpsGYDDGe.jpg"/>
															</div>
							<div class="lb-product-center-section__text">单光子探测</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=264" title="光电探测">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光电探测器分类图2-FsHkwAQ0v_LJt0Mk7WfXgVGvp8GQ.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光电探测</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=266" title="光束分析">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光束分析仪分类图-Fuj7N93KQTBW3-ML4DkFM-X2gQ40.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光束分析</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=331" title="偏振测量仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/偏振探测仪分类图-FlIzyk5O_P9wt18QVsg5bR-FOktv.jpg"/>
															</div>
							<div class="lb-product-center-section__text">偏振测量仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=263" title="光束调制器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光束调制分类图-FqmgvMcMYoyKVjoMfxHv1V81jT-h.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光束调制器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=268" title="相机">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/相机分类图-FjKh07tOptDC04EcfuuFJ375NG0x.jpg"/>
															</div>
							<div class="lb-product-center-section__text">相机</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/184?sid=333" title="电源及电子设备">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/电源及电子设备-FlMAhDKhPm1_x5s7Id-LZvkb6yqU.jpg"/>
															</div>
							<div class="lb-product-center-section__text">电源及电子设备</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--10">
				<div class="lb-product-center-section__title"><span>光源</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=340" title="LED光源">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/LED光源分类图-FiyBzTbm09Cof1Hmi0kEnaj8nMpc.jpg"/>
															</div>
							<div class="lb-product-center-section__text">LED光源</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=343" title="宽谱光源">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/2宽谱连续光源分类(新增）-Fpeq5htS06e6vnD1snaokp6_DTTU.jpg"/>
															</div>
							<div class="lb-product-center-section__text">宽谱光源</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=339" title="连续及准连续激光器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/连续及准连续激光器分类图-Fh3jcDPM0YgIaCgJlROMUbgTNsex.jpg"/>
															</div>
							<div class="lb-product-center-section__text">连续及准连续激光器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=346" title="脉冲激光器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/超快光纤激光器-FkftynHrAf7BDakNGzeHmfXgxaYf.jpg"/>
															</div>
							<div class="lb-product-center-section__text">脉冲激光器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=349" title="窄线宽激光器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/单纵模激光器-Fh7FLEJWuG_IBlYk3EIFzsnzCwbS.jpg"/>
															</div>
							<div class="lb-product-center-section__text">窄线宽激光器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=347" title="氦氖激光器">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/氦氖激光器-Fuzfh9rxYGzabLg4-i8dNWV6q14j.jpg"/>
															</div>
							<div class="lb-product-center-section__text">氦氖激光器</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/144?sid=348" title="驱动器控制器及配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/驱动器控制器及配件分类图-FsMwT9sBR4DAE1D5RtjhYjcBw3YH.jpg"/>
															</div>
							<div class="lb-product-center-section__text">驱动器控制器及配件</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--11">
				<div class="lb-product-center-section__title"><span>光谱</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=372" title="高速光纤光谱仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/高速光纤光谱仪-FtpbKSCvYiwX9SDeF9S4kRdMPjOK.jpg"/>
															</div>
							<div class="lb-product-center-section__text">高速光纤光谱仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=375" title="高灵敏度光纤光谱仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/高灵敏度光纤光谱仪-Fpp9hmLZsbgbOgACRzo5RlDgmOTj.jpg"/>
															</div>
							<div class="lb-product-center-section__text">高灵敏度光纤光谱仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=376" title="高分辨率光纤光谱仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/高分辨率光纤光谱仪-FpRNpoqODOH-Wr4_31n5qf4tCtaD.jpg"/>
															</div>
							<div class="lb-product-center-section__text">高分辨率光纤光谱仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=373" title="高稳定光纤光谱仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/高稳定光纤光谱仪-FgJWOvKDBPZBXEgoiPNzvbJNTCMM.jpg"/>
															</div>
							<div class="lb-product-center-section__text">高稳定光纤光谱仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=374" title="近红外光纤光谱仪">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/近红外光纤光谱仪-Fo18IPPoEK6ETV_F1xhjxZVBHNXM.jpg"/>
															</div>
							<div class="lb-product-center-section__text">近红外光纤光谱仪</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/326?sid=379" title="光谱配件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光谱配件分类图-FsaRepBnIydo1GvuEboTiFexBqq1.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光谱配件</div>
						</a>
					</div>
									</div>
			</div>
						<div class="lb-product-center-section lb-product-center-section--12">
				<div class="lb-product-center-section__title"><span>科研系统与套件</span></div>
				<div class="lb-product-center-section__list">
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=335" title="量子">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/量子分类图-FvKv1XPqyrF7oWA91kh8u6LDwPOQ.jpg"/>
															</div>
							<div class="lb-product-center-section__text">量子</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=334" title="OCT">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/OCT分类图-FhgAOzt4czJ6wJZXryCxVZBzv60R.jpg"/>
															</div>
							<div class="lb-product-center-section__text">OCT</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=352" title="成像">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/成像分类图-Foh7_3ruJi8bVYd3IyCLqZkrfe6k.jpg"/>
															</div>
							<div class="lb-product-center-section__text">成像</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=399" title="精密检测">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/精密检测分类图-Fjv5gBTs06dslQKmHmYWATwYUizr.jpg"/>
															</div>
							<div class="lb-product-center-section__text">精密检测</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=400" title="光镊">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/光镊分类图-Fi5XD0rxHO52lStCwET1hHDcTJMg.jpg"/>
															</div>
							<div class="lb-product-center-section__text">光镊</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=401" title="精密加工">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/精密加工分类图-Ft5viDSijbmrHgIeBMtJ67QwQg0K.jpg"/>
															</div>
							<div class="lb-product-center-section__text">精密加工</div>
						</a>
					</div>
										<div class="lb-product-center-section__item">
						<a href="/product_center/327?sid=402" title="软件">
							<div class="lb-product-center-section__img">
								<img src="https://images.lbtek.com/mall/category/软件分类图-FshdVdzgluvtOOqNGHdy1bQmQ4qE.jpg"/>
															</div>
							<div class="lb-product-center-section__text">软件</div>
						</a>
					</div>
									</div>
			</div>
					</div>
	</div>
</div>


<RouterView/>

</template>

<script>
import { RouterView } from 'vue-router'
export default {
  name: 'ProductView',
  data() {
    return {
      // 如果需要响应式数据可以在这里定义
    }
  }
}
</script>

<style>
 
/* @import '../../public/lib/quote/header.css'; */
@import '/libs/quotes/css_v2.css';
@import '/libs/quotes/header.css';
@import '/libs/quotes/homepage.css';
@import '/libs/quotes/product.css';
/* 如果需要样式可以在这里添加 */
</style>
